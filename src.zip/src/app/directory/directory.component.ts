import { Component } from '@angular/core';

@Component({
  selector: 'app-directory',
  imports: [],
  templateUrl: './directory.component.html',
  styleUrl: './directory.component.css'
})
export class DirectoryComponent {

}
