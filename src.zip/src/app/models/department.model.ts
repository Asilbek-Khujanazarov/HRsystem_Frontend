export interface Department {
    departmentId: number;
    departmentName: string;
  }